import React from 'react';
import { BrowserRouter, Routes, Route } from 'react-router-dom'
import Dashboard from './Dashboard';
import Login from './Login';

const logado = localStorage.getItem('@user');
function App() {
  return (
    <div className="App">
      <BrowserRouter>
        <Routes>
          {logado && <Route path="/admin" exact element={<Dashboard />} />}
          {!logado && <Route path="/admin" element={<Login logado={logado} />} />}

          {/* <Route path='/admin' element={<Dashboard></Dashboard>}></Route> */}
        </Routes>
      </BrowserRouter>
    </div>
  )
}
export default App;
