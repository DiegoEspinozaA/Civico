import React, { useEffect, useState } from 'react';
import axios from 'axios';
import Swal from 'sweetalert2';
import withReactContent from 'sweetalert2-react-content';
import { show_alerta } from './functions';
import Container from 'react-bootstrap/Container';
import Navbar from 'react-bootstrap/Navbar';
import { Dropdown, DropdownToggle, DropdownMenu, DropdownItem } from 'reactstrap'
import { useStyles } from './style';
import './dashboard.scss';
// import { useHistory } from 'react-router'


const url = 'https://civico.cl/menu/';


const Dashboard = () => {
    const classes = useStyles()
    const [categorias, setCategorias] = useState([]);
    const [id, setId] = useState('');
    const [nombre, setNombre] = useState('');
    const [operation, setOperation] = useState(1);
    const [title, setTitle] = useState('');
    const [isLoading, setLoading] = useState(true);

    //productos
    const [productos, setProductos] = useState([]);
    const [idProducto, setIdProducto] = useState('');
    const [nombreProducto, setNombreProducto] = useState('');
    const [descripcion, setDescripcion] = useState('');
    const [precio, setPrecio] = useState('');
    const [idfamilia, setIdFamilia] = useState('');
    const [seleccionada, setSeleccionada] = useState('');

    const getProducts = async () => {
        const respuesta = await axios.get(url);
        setProductos(respuesta.data);
    }
    const getFamilys = async () => {
        const respuesta = await axios.get(url + "familias")
        setCategorias(respuesta.data);
    }

    useEffect(() => {
        setLoading(false);
        getProducts();
        getFamilys();
    }, []);



    const openModalProducto = (op, id, nombre, precio, descripcion, id_familia, nombre_familia) => {
        setIdProducto('');
        setNombreProducto('');
        setDescripcion('');
        setPrecio('');
        setIdFamilia('');
        setTitle('');
        setSeleccionada('Seleccione una Familia');
        setOperation(op);
        if (op === 1) {
            setTitle('Registrar Producto');
        }
        else if (op === 2) {
            setTitle('Editar Producto');
            setIdProducto(id);
            setNombreProducto(nombre);
            setDescripcion(descripcion);
            setPrecio(precio);
            setIdFamilia(id_familia)
            setSeleccionada(nombre_familia);
        }
        window.setTimeout(function () {
            document.getElementById('nombre').focus();
        }, 500);
    }

    const openModal = (op, id, nombre) => {
        setId('');
        setNombre('')
        setOperation(op);
        if (op === 1) {
            setTitle('Registrar Familia');
        }
        else if (op === 2) {
            setTitle('Editar Familia');
            setNombre(nombre)
            setId(id);
        }
        window.setTimeout(function () {
            document.getElementById('nombre').focus();
        }, 500);
    }

    const validarProducto = () => {
        var parametros;
        var metodo;
        var ur;
        if (nombreProducto.trim() === '') {
            show_alerta('Escribe el nombre del producto', 'warning');
        }
        else if (descripcion.trim() === '') {
            show_alerta('Escribe la descripción del producto', 'warning');
        }
        else if (precio === '') {
            show_alerta('Escribe el precio del producto', 'warning');
        }
        else if (idfamilia === '') {
            show_alerta('Selecciona una familia', 'warning');
        }
        else {
            if (operation === 1) {
                parametros = { nombre: nombreProducto.trim(), descripcion: descripcion.trim(), precio: precio, id_familia: idfamilia };
                metodo = 'POST';
                ur = "https://civico.cl/menu/registrar/producto"
            }
            else {
                parametros = { id: idProducto, nombre: nombreProducto.trim(), descripcion: descripcion.trim(), precio: precio, id_familia: idfamilia };
                metodo = 'PUT';
                ur = "https://civico.cl/menu/editar/producto"
            }
            envarSolicitud(metodo, parametros, ur);
        }
    }

    const validar = () => {
        var parametros;
        var metodo;
        var ur;
        if (nombre.trim() === '') {
            show_alerta('Escribe el nombre de la familia', 'warning');
        }
        else {
            if (operation === 1) {

                parametros = { nombre: nombre.trim(), superfamilia: (activeCategory === "" || activeCategory === "Bebestibles" ? "Bebestible" : activeCategory) };
                metodo = 'POST';
                ur = "https://civico.cl/menu/registrar/familia"

            }
            else {
                parametros = { id: id, nombre: nombre.trim() };
                metodo = 'PUT';
                ur = "https://civico.cl/menu/editar/familia"
            }
            envarSolicitud(metodo, parametros, ur);
        }
    }



    const envarSolicitud = async (metodo, parametros, ur) => {
        await axios({ method: metodo, url: ur, data: parametros }).then(function (respuesta) {
            var estado = respuesta.status;
            if (estado === 200) {
                show_alerta('Operacion realizada con exito', 'success');
                //document.getElementById('btnCerrar').click();
                getFamilys();
                getProducts();
            }
        })
            .catch(function (error) {
                show_alerta('Error en la solicitud', 'error');
            });
    }

    const deleteFamily = (id, nombre) => {
        const MySwal = withReactContent(Swal);
        MySwal.fire({
            title: '¿Seguro de eliminar la Familia ' + nombre + ' y todos sus productos?',
            icon: 'question', text: 'No se podrá dar marcha atrás',
            showCancelButton: true, confirmButtonText: 'Si, eliminar', cancelButtonText: 'Cancelar'
        }).then((result) => {
            if (result.isConfirmed) {
                setId(id);
                envarSolicitud('DELETE', { id: id }, "https://civico.cl/menu/eliminar/familia");
            }
            else {
                show_alerta('La Familia NO fue eliminada', 'info');
            }
        });
    }

    const deleteProduct = (id, nombre) => {
        if (checkedBoxes.length <= 1) {
            const MySwal = withReactContent(Swal);
            MySwal.fire({
                title: '¿Seguro de eliminar el producto ' + nombre + ' ?',
                icon: 'question', text: 'No se podrá dar marcha atrás',
                showCancelButton: true, confirmButtonText: 'Si, eliminar', cancelButtonText: 'Cancelar'
            }).then((result) => {
                if (result.isConfirmed) {
                    setIdProducto(id);
                    envarSolicitud('DELETE', { id: id }, "https://civico.cl/menu/delete");
                }
                else {
                    show_alerta('El Producto NO fue eliminado', 'info');
                }
            });
        }
        else {
            deleteProducts();
        }
    }

    const [dropdown, setDropdown] = useState(false);
    const abrirCerrarDropdown = () => {
        setDropdown(!dropdown);
    }

    const dropdownAccion = (id, nombre) => {
        setIdFamilia(id);
        setSeleccionada(nombre)
    }



    const [checkedBoxes, setCheckBoxes] = useState([]);

    const toggleCheckbox = (e, item) => {
        if (e.target.checked) { //si le doy a true debo agregarlo
            let arr = checkedBoxes;
            arr.push(item.id);
            setCheckBoxes(arr)
        }
        else { //si esta desmarcado devo verificar si esta en la lista para quitarlo
            const items = checkedBoxes.filter((x) => x !== item.id);
            setCheckBoxes(items);
        }
    }

    const deleteProducts = () => {
        const MySwal = withReactContent(Swal);
        MySwal.fire({
            title: '¿Seguro que quiere eliminar los productos seleccionados?',
            icon: 'question', text: 'No se podrá dar marcha atrás',
            showCancelButton: true, confirmButtonText: 'Si, eliminar', cancelButtonText: 'Cancelar'
        }).then((result) => {
            if (result.isConfirmed) {
                envarSolicitud('DELETE', { ids: checkedBoxes }, "https://civico.cl/delete/products");
                getProducts();
            }
            else {
                show_alerta('Los productos NO fueron eliminado', 'info');
            }
        });
    }

    const subirFamilia = (id, superfamilia) => {
        var parametros = { id: id, superfamilia: superfamilia };
        var metodo = 'PUT';
        var ur = "https://civico.cl/menu/editar/subirfamilia"

        axios({ method: metodo, url: ur, data: parametros }).then(function (respuesta) {
            var estado = respuesta.status;
            if (estado === 200) {
                show_alerta('Operacion realizada con exito', 'success');
                //document.getElementById('btnCerrar').click();
                getFamilys();
                getProducts();
            }
        })
            .catch(function (error) {
                show_alerta('Error en la solicitud', 'error');
            });
    }

    const bajarFamilia = (id, superfamilia) => {
        var parametros = { id: id, superfamilia: superfamilia };
        var metodo = 'PUT';
        var ur = "https://civico.cl/menu/editar/bajarfamilia"

        axios({ method: metodo, url: ur, data: parametros }).then(function (respuesta) {
            var estado = respuesta.status;
            if (estado === 200) {
                show_alerta('Operacion realizada con exito', 'success');
                //document.getElementById('btnCerrar').click();
                getFamilys();
                getProducts();
            }
        })
            .catch(function (error) {
                show_alerta('Error en la solicitud', 'error');
            });
    }

    const subirProducto = (id) => {
        var parametros = { id: id };
        var metodo = 'PUT';
        var ur = "https://civico.cl/menu/editar/subirproducto"

        axios({ method: metodo, url: ur, data: parametros }).then(function (respuesta) {
            var estado = respuesta.status;
            if (estado === 200) {
                show_alerta('Operacion realizada con exito', 'success');
                getFamilys();
                getProducts();
            }
        })
            .catch(function (error) {
                show_alerta('Error en la solicitud', 'error');
            });
    }

    const bajarProducto = (id) => {
        var parametros = { id: id };
        var metodo = 'PUT';
        var ur = "https://civico.cl/menu/editar/bajarproducto"

        axios({ method: metodo, url: ur, data: parametros }).then(function (respuesta) {
            var estado = respuesta.status;
            if (estado === 200) {
                show_alerta('Operacion realizada con exito', 'success');
                getFamilys();
                getProducts();
            }
        })
            .catch(function (error) {
                show_alerta('Error en la solicitud', 'error');
            });
    }

    const cate = [...new Set(productos.map((item) => item.nombre_familia))];
    const bebestibles = [], comidas = [];
    const [activeCategory, setActiveCategory] = useState("");


    cate.forEach(function (nombre) {
        const x = productos.filter((item) => item.nombre_familia === nombre);
        if (x[0].superfamilia === "Comida") {
            comidas.push(x);
        }
        else {
            bebestibles.push(x);
        }
    });

    const filterItems = (category) => {
        setActiveCategory(category);
    };


    const categoriasB = [], categoriasC = [];
    categorias.forEach(function (nombre) {
        if (nombre.superfamilia === "Bebestible") {
            categoriasB.push(nombre);
        }
        else {
            categoriasC.push(nombre);
        }
    });

    const logout = () => {
        localStorage.clear();
        window.location.reload();
    }
    return isLoading ? (
        <></>
    ) : (
        <div className="body">
            <div className={classes.container}>
                <Navbar className={activeCategory === "" || activeCategory === "Bebestibles" ? "color-nav1" : "color-nav2"} fixed="top" >
                    <Container>
                        <button onClick={() => openModal(1)} className='btn btn-light' data-bs-toggle='modal' data-bs-target='#modalFamily'>
                            <i className='fa fa-plus'></i> Añadir Familia
                        </button>
                        {categorias.length > 0 &&
                            <button onClick={() => openModalProducto(1)} className='btn btn-light' data-bs-toggle='modal' data-bs-target='#modalProducts'>
                                <i className='fa fa-plus'></i> Añadir Producto
                            </button>
                        }
                        <button onClick={logout} className='btn btn-light'>
                            <i className='fa fa-sign-out'></i>
                        </button>

                    </Container>
                </Navbar>
                <br />
                <div>
                    <div className="indicators">
                        <div id="i2">
                            <div className={activeCategory === "" || activeCategory === "Bebestibles" ? "navi-indicator1" : "navi-indicator1-inactive"} id={activeCategory === "" || activeCategory === "Bebestibles" ? "ni1" : "ni1-inactive"}></div>
                        </div>
                        <div id="i3">
                            <div className={activeCategory === "Comida" ? "navi-indicator2" : "navi-indicator1-inactive"} id={activeCategory === "Comida" ? "ni2" : "ni2-inactive"}></div>
                        </div>

                    </div>
                    <div className="navi">
                        <div className="navi-item2">
                            <button className="nav-button" id="startersbutton" onClick={() => filterItems("Bebestibles")}>
                                <div className="navi-icon"><i className="fas fa-wine-glass-alt"></i></div>
                                <div className="navi-text">Bebestibles</div>
                            </button>
                        </div>

                        <div className="navi-item3">
                            <button className="nav-button" id="mainsbutton" onClick={() => filterItems("Comida")}>
                                <div className="navi-icon"><i className="fas fa-utensils"></i></div>
                                <div className="navi-text">Comida</div>
                            </button>
                        </div>

                    </div>
                </div>
                <div className='tabla'>
                    {activeCategory === "Bebestibles" || activeCategory === "" ?
                        categoriasB.map((categoria, indice) =>
                            <div key={categoria.id} className="categoriasB">
                                <h1>{categoria.nombre}&nbsp;
                                </h1>
                                <div className="btn-group align-top">
                                    <button onClick={() => openModal(2, categoria.id, categoria.nombre)}
                                        className='btn btn-sm btn-outline-dark' data-bs-toggle='modal' data-bs-target='#modalFamily'>
                                        <i className='fa-solid fa-edit'></i>
                                    </button>&nbsp;
                                    <button onClick={() => deleteFamily(categoria.id, categoria.nombre)} className='btn btn-sm btn-outline-dark'>
                                        <i className='fa-solid fa-trash'></i>
                                    </button>&nbsp;
                                    {indice !== 0 && <button onClick={() => subirFamilia(categoria.id, "Bebestible")} className='btn btn-sm btn-outline-dark'>
                                        <i className='fa-solid fa-arrow-up-long'></i>
                                    </button>}
                                    {indice !== categoriasB.length - 1 && <button onClick={() => bajarFamilia(categoria.id, "Bebestible")} className='btn btn-sm btn-outline-dark'>
                                        <i className='fa-solid fa-arrow-down-long'></i>
                                    </button>}
                                </div>

                                {productos.filter(producto => producto.id_familia === categoria.id).length > 0 ?
                                    <div className="table-responsive">
                                        <table className="table table-hover">
                                            <thead>
                                                <tr><th></th><th>Nombre</th><th>Precio</th><th>Descripción</th><th>Acciones</th></tr>
                                            </thead>
                                            <tbody className="table-group-divider">
                                                {productos.filter(producto => producto.id_familia === categoria.id).map((producto, indice2) =>
                                                    <tr key={producto.id}>
                                                        <td><input type="checkbox" className="selectsingle" value="{producto.id}" checked={checkedBoxes.find((p) => p === producto.id)} onChange={(e) => toggleCheckbox(e, producto)} />
                                                            &nbsp;&nbsp;
                                                        </td>
                                                        <td>{producto.nombre}
                                                        </td>
                                                        <td>{producto.precio}</td>
                                                        <td>{producto.descripcion}</td>
                                                        <td><div className="btn-group align-top">
                                                            <button onClick={() => openModalProducto(2, producto.id, producto.nombre, producto.precio, producto.descripcion, producto.id_familia, producto.nombre_familia)}
                                                                className='btn btn-sm btn-outline-dark' data-bs-toggle='modal' data-bs-target='#modalProducts'>
                                                                Editar
                                                            </button>
                                                            <button onClick={() => deleteProduct(producto.id, producto.nombre)} className='btn btn-sm btn-outline-dark'>
                                                                <i className='fa-solid fa-trash'></i>
                                                            </button>

                                                            {/* Agregar  bien las funcionalidades aqui */}
                                                            {indice2 !== 0 && <button onClick={() => subirProducto(producto.id)} className='btn btn-sm btn-outline-dark'>
                                                                <i className='fa-solid fa-arrow-up-long'></i>
                                                            </button>}
                                                            {indice2 !== productos.filter(producto => producto.id_familia === categoria.id).length - 1 && <button onClick={() => bajarProducto(producto.id)} className='btn btn-sm btn-outline-dark'>
                                                                <i className='fa-solid fa-arrow-down-long'></i>
                                                            </button>}

                                                        </div>
                                                        </td>
                                                    </tr>
                                                )
                                                }
                                            </tbody>

                                        </table>
                                    </div> : <span className="errorTabla"><br></br>No hay productos para mostrar</span>
                                }
                                <br></br>
                                <br></br>
                            </div>
                        )
                        :
                        categoriasC.map((categoria, indice) =>
                            <div key={categoria.id} className="">
                                <h1>{categoria.nombre}&nbsp;
                                </h1>
                                <div className="btn-group align-top">
                                    <button onClick={() => openModal(2, categoria.id, categoria.nombre)}
                                        className='btn btn-sm btn-outline-dark' data-bs-toggle='modal' data-bs-target='#modalFamily'>
                                        <i className='fa-solid fa-edit'></i>
                                    </button>&nbsp;
                                    <button onClick={() => deleteFamily(categoria.id, categoria.nombre)} className='btn btn-sm btn-outline-dark'>
                                        <i className='fa-solid fa-trash'></i>
                                    </button>&nbsp;
                                    {indice !== 0 && <button onClick={() => subirFamilia(categoria.id, "Comida")} className='btn btn-sm btn-outline-dark'>
                                        <i className='fa-solid fa-arrow-up-long'></i>
                                    </button>}
                                    {indice !== categoriasC.length - 1 && <button onClick={() => bajarFamilia(categoria.id, "Comida")} className='btn btn-sm btn-outline-dark'>
                                        <i className='fa-solid fa-arrow-down-long'></i>
                                    </button>}
                                </div>
                                {productos.filter(producto => producto.id_familia === categoria.id).length > 0 ?
                                    <div className="table-responsive">

                                        <table className="table table-bordered">
                                            <thead >
                                                <tr><th></th><th>Nombre</th><th>Precio</th><th>Descripción</th><th>Acciones</th></tr>
                                            </thead>
                                            <tbody className="table-group-divider">
                                                {productos.filter(producto => producto.id_familia === categoria.id).map((producto, indice2) =>
                                                    <tr key={producto.id}>
                                                        <td><input type="checkbox" className="selectsingle" value="{producto.id}" checked={checkedBoxes.find((p) => p === producto.id)} onChange={(e) => toggleCheckbox(e, producto)} />
                                                            &nbsp;&nbsp;
                                                        </td>
                                                        <td>{producto.nombre}
                                                        </td>
                                                        <td>{producto.precio}</td>
                                                        <td>{producto.descripcion}</td>
                                                        <td><div className="btn-group align-top">
                                                            <button onClick={() => openModalProducto(2, producto.id, producto.nombre, producto.precio, producto.descripcion, producto.id_familia, producto.nombre_familia)}
                                                                className='btn btn-sm btn-outline-dark' data-bs-toggle='modal' data-bs-target='#modalProducts'>
                                                                Editar
                                                            </button>
                                                            <button onClick={() => deleteProduct(producto.id, producto.nombre)} className='btn btn-sm btn-outline-dark'>
                                                                <i className='fa-solid fa-trash'></i>
                                                            </button>
                                                            {indice2 !== 0 && <button onClick={() => subirProducto(producto.id)} className='btn btn-sm btn-outline-dark'>
                                                                <i className='fa-solid fa-arrow-up-long'></i>
                                                            </button>}
                                                            {indice2 !== productos.filter(producto => producto.id_familia === categoria.id).length - 1 && <button onClick={() => bajarProducto(producto.id)} className='btn btn-sm btn-outline-dark'>
                                                                <i className='fa-solid fa-arrow-down-long'></i>
                                                            </button>}

                                                        </div>
                                                        </td>
                                                    </tr>
                                                )
                                                }
                                            </tbody>

                                        </table>
                                    </div> : <span className="errorTabla"><br></br>No hay productos para mostrar</span>
                                }
                            </div>
                        )
                    }
                </div>
                <div id='modalFamily' className='modal fade' aria-hidden='true'>
                    <div className='modal-dialog'>
                        <div className='modal-content'>
                            <div className='modal-header'>
                                <label className='h5'>{title}</label>
                                <button type='button' className='btn-close' data-bs-dismiss='modal' aria-label='Close'></button>
                            </div>
                            <div className='modal-body'>
                                <input type='hidden' id='id'></input>
                                <div className='input-group mb-3'>
                                    <input type='text' id='nombre' className='form-control' placeholder='Nombre' value={nombre}
                                        onChange={(e) => setNombre(e.target.value)}></input>
                                </div>
                                <div className='d-grid col-6 mx-auto'>
                                    <button onClick={() => validar()} className='btn btn-success'>
                                        <i className='fa-solid fa-floppy-disk'></i> Guardar
                                    </button>
                                </div>
                            </div>
                            <div className='modal-footer'>
                                <button type='button' id='btnCerrar' className='btn btn-secondary' data-bs-dismiss='modal'>Cerrar</button>
                            </div>
                        </div>
                    </div>
                </div>

                <div id='modalProducts' className='modal fade' aria-hidden='true'>
                    <div className='modal-dialog'>
                        <div className='modal-content'>
                            <div className='modal-header'>
                                <label className='h5'>{title}</label>
                                <button type='button' className='btn-close' data-bs-dismiss='modal' aria-label='Close'></button>
                            </div>
                            <div className='modal-body'>
                                <input type='hidden' id='id'></input>

                                <div className=''>
                                    <span>Familia</span>
                                    <Dropdown isOpen={dropdown} toggle={abrirCerrarDropdown}>
                                        <DropdownToggle caret>
                                            {seleccionada}
                                        </DropdownToggle>

                                        <DropdownMenu>
                                            {activeCategory === "" || activeCategory === "Bebestibles" ? categoriasB.map((categoria) =>
                                                <DropdownItem key={categoria.id} onClick={() => dropdownAccion(categoria.id, categoria.nombre)}>
                                                    {categoria.nombre}
                                                </DropdownItem>
                                            ) :
                                                categoriasC.map((categoria) =>
                                                    <DropdownItem key={categoria.id} onClick={() => dropdownAccion(categoria.id, categoria.nombre)}>
                                                        {categoria.nombre}
                                                    </DropdownItem>
                                                )}

                                        </DropdownMenu>
                                    </Dropdown>
                                </div>
                                <br></br>
                                <div className=''>
                                    <span>Nombre producto</span>
                                    <input type='text' id='nombreProducto' className='form-control' placeholder='Nombre' value={nombreProducto}
                                        onChange={(e) => setNombreProducto(e.target.value)}></input>
                                </div>
                                <br></br>
                                <div className=''>
                                    <span>Descripcion</span>
                                    <input type='text' id='descripcion' className='form-control' placeholder='Descripción' value={descripcion}
                                        onChange={(e) => setDescripcion(e.target.value)}></input>
                                </div>
                                <br></br>
                                <div className=''>
                                    <span>Precio</span>
                                    <input type='text' id='precio' className='form-control' placeholder='Precio' value={precio}
                                        onChange={(e) => setPrecio(e.target.value)}></input>
                                </div>
                                <br></br>
                                <div className='d-grid col-6 mx-auto'>
                                    <button onClick={() => validarProducto()} className='btn btn-success'>
                                        <i className='fa-solid fa-floppy-disk'></i> Guardar
                                    </button>
                                </div>
                            </div>
                            <div className='modal-footer'>
                                <button type='button' id='btnCerrar' className='btn btn-secondary' data-bs-dismiss='modal'>Cerrar</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    )
}
export default Dashboard


