import { makeStyles } from '@material-ui/core/styles'


export const useStyles = makeStyles(({ spacing }) => ({

    container: {
        marginTop: spacing(10)
    }
}))