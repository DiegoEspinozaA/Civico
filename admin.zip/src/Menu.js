import React from 'react';
const Menu = ({ items, i }) => {

    return (
        <div>
            <div className='tabla'>
                <h1>{categoria[0].nombre}&nbsp;

                </h1>
                <div className="btn-group align-top">
                    <button onClick={() => openModal(2, categoria.id, categoria.nombre)}
                        className='btn btn-sm btn-outline-dark' data-bs-toggle='modal' data-bs-target='#modalFamily'>
                        <i className='fa-solid fa-edit'></i>
                    </button>&nbsp;
                    <button onClick={() => deleteFamily(categoria.id, categoria.nombre)} className='btn btn-sm btn-outline-dark'>
                        <i className='fa-solid fa-trash'></i>
                    </button>&nbsp;
                    {indice !== 0 && <button onClick={() => subirFamilia(categoria.id)} className='btn btn-sm btn-outline-dark'>
                        <i className='fa-solid fa-arrow-up-long'></i>
                    </button>}
                    {indice !== categorias.length - 1 && <button onClick={() => bajarFamilia(categoria.id, categoria.nombre)} className='btn btn-sm btn-outline-dark'>
                        <i className='fa-solid fa-arrow-down-long'></i>
                    </button>}
                </div>
                {items.map((categoria, indice) =>
                    // <div key={categoria.id} className="col-12 col-lg-8 offset-0 offset-lg-2">
                    <div key={categoria.id} className="">
                        {productos.filter(producto => producto.id_familia === categoria.id).length > 0 ?
                            <div className="table-responsive">
                                <table className="table table-bordered">
                                    <thead >
                                        <tr><th></th><th>Nombre</th><th>Precio</th><th>Desc</th><th></th></tr>
                                    </thead>
                                    <tbody className="table-group-divider">
                                        {productos.filter(producto => producto.id_familia === categoria.id).map((producto, indice2) =>
                                            <tr key={producto.id}>
                                                <td><input type="checkbox" className="selectsingle" value="{producto.id}" checked={checkedBoxes.find((p) => p === producto.id)} onChange={(e) => toggleCheckbox(e, producto)} />
                                                    &nbsp;&nbsp;
                                                </td>
                                                <td>{producto.nombre}
                                                </td>
                                                <td>{producto.precio}</td>
                                                <td>{producto.descripcion}</td>
                                                <td><div className="btn-group align-top">
                                                    <button onClick={() => openModalProducto(2, producto.id, producto.nombre, producto.precio, producto.descripcion, producto.id_familia, producto.nombre_familia)}
                                                        className='btn btn-sm btn-outline-dark' data-bs-toggle='modal' data-bs-target='#modalProducts'>
                                                        Editar
                                                    </button>
                                                    <button onClick={() => deleteProduct(producto.id, producto.nombre)} className='btn btn-sm btn-outline-dark'>
                                                        <i className='fa-solid fa-trash'></i>
                                                    </button>

                                                    {/* Agregar  bien las funcionalidades aqui */}
                                                    {indice2 !== 0 && <button onClick={() => subirProducto(producto.id)} className='btn btn-sm btn-outline-dark'>
                                                        <i className='fa-solid fa-arrow-up-long'></i>
                                                    </button>}
                                                    {indice2 !== productos.filter(producto => producto.id_familia === categoria.id).length - 1 && <button onClick={() => bajarProducto(producto.id)} className='btn btn-sm btn-outline-dark'>
                                                        <i className='fa-solid fa-arrow-down-long'></i>
                                                    </button>}

                                                </div>
                                                </td>
                                            </tr>
                                        )
                                        }
                                    </tbody>

                                </table>
                            </div> : <span className="errorTabla"><br></br>No hay productos para mostrar</span>
                        }
                    </div>
                )
                }
            </div>
        </div >
    );
};

export default Menu;

