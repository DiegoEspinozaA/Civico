import React from 'react';
import * as yup from "yup";
import { ErrorMessage, Formik, Form, Field } from "formik";
import Axios from "axios";
import "./login.scss"

function Login({ logado = false }) {
    const handleLogin = (values) => {
        Axios.post("https://civico.cl/menu/login", {
            username: values.username,
            password: values.password,
        }).then((response) => {
            const page = response.data;
            console.log(page)
            if ((page === true)) {
                localStorage.setItem('@user', JSON.stringify(response.config.data));
                window.location.reload();

            } else {
                alert(response.data.msg);
            }

        });
    };
    const validationsLogin = yup.object().shape({
        username: yup
            .string()
            .required("Ingrese nombre de usuario"),
        password: yup
            .string()
            .required("Ingrese la contraseña"),
    });

    return (
        <div className="bodyAdmin">
            <div className="login">
                <h1 className="titulo">Login</h1>
                <Formik
                    initialValues={{}}
                    onSubmit={handleLogin}

                    validationSchema={validationsLogin}
                >
                    <Form>
                        <Field name="username" type="text" placeholder="Nombre de usuario" autoComplete="off" autoCapitalize='none'></Field>
                        <ErrorMessage
                            component="span"
                            name="username"
                            className="form-error"
                        />
                        <Field name="password" type="password" placeholder="Contraseña"></Field>
                        <ErrorMessage
                            component="span"
                            name="password"
                            className="form-error"
                        />

                        {/* <Field name="username" type='user' placeholder="Usuario" autoComplete="off" />

                        <Field id="password" name="password" type='password' placeholder="Contraseña" /> */}

                        <button className="login-button" type="submit">
                            Ingresar
                        </button>
                    </Form>
                </Formik>
            </div>
        </div>
    );
}

export default Login;