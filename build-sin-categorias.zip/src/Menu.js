import React from 'react';
const Menu = ({ items, i }) => {
  //Nombre es el nombre de la familia que se pasa por parametros, un map de los distintos nombres de las familias
  function numberWithCommas(x) {
    var parts = x.toString().split(".");
    parts[0] = parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, ".");
    return parts.join(".");
  }

  function esCivico(x) {
    var lower = x.toLowerCase();
    return lower.includes("cívico") || lower.includes("civico") || lower.includes("civica") || lower.includes("cívica");
  }
  return (
    <div>
      <div>
        <div className="eight">
          <h1 className="titulo-categoria">{items[0].nombre_familia} </h1>
        </div>
      </div>
      {
        items.length % 2 === 0 &&
        <div className="items">
          {items.map((producto, id) =>
            <div key={id}>
              <div className="precio-nombre">
                <h2 className="nombre-item">{producto.nombre}</h2>
                <span></span>
                <h3 className="precio">${numberWithCommas(producto.precio)}</h3>
              </div>
              <p className="item-description">{producto.descripcion}</p>
            </div>
          )}
        </div>
      }
      {
        items.length % 2 !== 0 &&
        <div>
          <div className="items">
            {items.slice(0, items.length - 1).map((producto, id) =>
              <div key={id}>
                <div className="precio-nombre">
                  <h2 className="nombre-item">{producto.nombre}</h2>
                  <span></span>
                  <h3 className="precio">${numberWithCommas(producto.precio)}</h3>
                </div>
                <p className="item-description">{producto.descripcion}</p>
              </div>
            )}
          </div>
          <div className='item-separado'>
            {items.slice(items.length - 1, items.length).map((producto, id) =>
              <div key={id}>
                <div className="precio-nombre">
                  {esCivico(producto.nombre) ? <h2 className="nombre-item">{producto.nombre} ⋆</h2> : <h2 className="nombre-item">{producto.nombre}</h2>}
                  <span></span>
                  <h3 className="precio">${numberWithCommas(producto.precio)}</h3>
                </div>
                <p className="item-description">{producto.descripcion}</p>
              </div>
            )}
          </div>
        </div>

      }
    </div >
  );
};

export default Menu;
