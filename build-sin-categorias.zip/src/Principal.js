import React, { useEffect, useState } from 'react';
import Menu from './Menu';
import axios from 'axios';

const url = 'https://civico.cl/menu/';

let axiosConfig = {
  headers: {
    'Content-Type': 'application/json;charset=UTF-8',
    "Access-Control-Allow-Origin": "*",
  }
};


function App() {
  const [productos, setProductos] = useState([]);
  const [isLoading, setLoading] = useState(true);

  useEffect(() => {
    const obtenerProductos = async () => {
      const respuesta = await axios.get(url, axiosConfig);
      setProductos(respuesta.data);
      setLoading(false);
    }

    obtenerProductos();


  }, []);

  const categorias = [...new Set(productos.map((item) => item.nombre_familia))];
  const todos = [], bebestibles = [], comidas = [];

  categorias.forEach(function (nombre) {
    const x = productos.filter((item) => item.nombre_familia === nombre);
    if (x[0].superfamilia === "Comida") {
      comidas.push(x);
    }
    else {
      bebestibles.push(x);
    }
    todos.push(x);
  });


  const [menuItems, setMenuItems] = useState(todos);
  const [aux, setAux] = useState(0);
  const [activeCategory, setActiveCategory] = useState("");


  const filterItems = (category) => {
    setAux(1);
    setActiveCategory(category);
    if (category === "Todos") {
      setMenuItems(todos);
    }
    else if (category === "Comida") {
      setMenuItems(comidas);
    }
    else {
      setMenuItems(bebestibles);
    }
  };


  return isLoading ? (
    <></>
  ) : (
    <div>
      {/* <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.11.1/css/all.css"></link> */}
      <div>
        <div className="menuGrande">
          <div id="front" className="menu-card">
            <div id="cafe-main-image-brand">
              <img className="header__logo" alt="logo" src={require('./civico.png')} />
            </div>
          </div>

          <div className="menu">

            <div className="container">
              <div class="categories">
                <div className={activeCategory === "" || activeCategory === "Bebestibles" ? "cat active" : "cat inactive"} onClick={() => filterItems("Bebestibles")}>
                  <div class="cat-img" style={{ backgroundImage: "url(https://eldiariony.com/wp-content/uploads/sites/2/2022/06/Botella-de-cerveza-oascura-shutterstock_1041913930.jpg?quality=75&strip=all&w=1200)" }}></div>

                  <span class="title">Bebestibles</span>
                </div>
                <div className={activeCategory === "Comida" ? "cat active" : "cat inactive"} onClick={() => filterItems("Comida")}>
                  <div class="cat-img" style={{ backgroundImage: "url(https://images.unsplash.com/photo-1606131731446-5568d87113aa?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxzZWFyY2h8MXx8YnVyZ2Vyc3xlbnwwfHwwfHw%3D&auto=format&fit=crop&w=500&q=60" }}></div>
                  <span class="title">Comida</span>
                </div>
              </div>
              {/* <div className="indicators">
                <div id="i2">
                  <div className={activeCategory === "" || activeCategory === "Bebestibles" ? "navi-indicator1" : "navi-indicator1-inactive"} id={activeCategory === "" || activeCategory === "Bebestibles" ? "ni1" : "ni1-inactive"}></div>
                </div>
                <div id="i3">
                  <div className={activeCategory === "Comida" ? "navi-indicator2" : "navi-indicator1-inactive"} id={activeCategory === "Comida" ? "ni2" : "ni2-inactive"}></div>
                </div>

              </div>
              <div className="navi">
                <div className="navi-item2">
                  <button className={activeCategory === "" || activeCategory === "Bebestibles" ? "nav-button active" : "nav-button"} id="startersbutton" onClick={() => filterItems("Bebestibles")}>
                    <div className="navi-icon"><span role="img" aria-labelledby="bebestible">🍻</span></div>
                    <div className="navi-text">Bebestibles</div>
                  </button>
                </div>

                <div className="navi-item3">
                  <button className={activeCategory === "Comida" ? "nav-button active" : "nav-button"} id="mainsbutton" onClick={() => filterItems("Comida")}>
                    <div className="navi-icon" ><span role="img" aria-labelledby="comida">🍔</span></div>
                    <div className="navi-text">Comida</div>

                  </button>
                </div> */}

              {/* </div> */}

            </div>


            {aux === 0 ?
              bebestibles.map((categoria, id) =>
                <Menu key={id} items={categoria} i={id}></Menu>
              )

              :

              menuItems.map((categoria, id) =>
                <Menu key={id} items={categoria} i={id}></Menu>
              )
            }

          </div >
        </div >
      </div >
    </div >
  );
}

export default App;