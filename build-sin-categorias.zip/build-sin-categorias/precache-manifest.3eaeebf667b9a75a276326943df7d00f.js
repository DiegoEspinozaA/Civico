self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "2b0045a412e541d243d88d30626e9a77",
    "url": "/yemo/index.html"
  },
  {
    "revision": "d3a6df51fd109e4729f6",
    "url": "/yemo/static/css/main.a2353926.chunk.css"
  },
  {
    "revision": "492df337a28fe6f9424d",
    "url": "/yemo/static/js/2.b27f96b4.chunk.js"
  },
  {
    "revision": "7574cc173e4511922fab76505fa5d6cc",
    "url": "/yemo/static/js/2.b27f96b4.chunk.js.LICENSE.txt"
  },
  {
    "revision": "d3a6df51fd109e4729f6",
    "url": "/yemo/static/js/main.46cbcdff.chunk.js"
  },
  {
    "revision": "6b17fe356054b5d2cbe4",
    "url": "/yemo/static/js/runtime-main.46afdf4e.js"
  },
  {
    "revision": "93a3695c3ce6db03735a591281a74568",
    "url": "/yemo/static/media/Kameron-Regular.93a3695c.ttf"
  },
  {
    "revision": "20d41940068e45b114d32b48d684ef39",
    "url": "/yemo/static/media/Raleway-Regular.20d41940.ttf"
  },
  {
    "revision": "96c06980712a33c574f9933a25e75cf9",
    "url": "/yemo/static/media/SFNSText-Regular.96c06980.otf"
  },
  {
    "revision": "ac9ebfc36e4764af82781bfad168cb21",
    "url": "/yemo/static/media/civico.ac9ebfc3.png"
  },
  {
    "revision": "0464e4e341ee106cbf5790cbe50e6d9c",
    "url": "/yemo/static/media/fondo.0464e4e3.png"
  }
]);