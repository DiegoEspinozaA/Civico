const express = require('express');
const server = express();
const mysql = require('mysql');
const cors = require('cors');

const bcrypt = require("bcrypt");

const db = mysql.createPool({
    host: "localhost",
    user: "civicocl_carta",
    password: "+ys?Hoh;)_~O",
    database: "civicocl_carta",
    charset: "utf8mb4",
});

server.use(express.json());
server.use(cors());

//Registrar producto
server.post("/menu/registrar/producto", (req, res) => {
    const { nombre } = req.body;
    const { precio } = req.body;
    const { descripcion } = req.body;
    const { id_familia } = req.body;

    let sql = "INSERT INTO producto (nombre, precio, id_familia, descripcion) VALUES (?,?,?,?)"
    db.query(sql, [nombre, precio, id_familia, descripcion], (err, result) => {
        if (err) {
            console.log(err);
        } else {
            res.send(result);
        }
    })
});


//Registrar familia
server.post("/menu/registrar/familia", (req, res) => {
    const { nombre } = req.body;
    const { superfamilia } = req.body;
    let sql = "insert into familia (nombre, superfamilia) values (?,?)";
    db.query(sql, [nombre, superfamilia], (err, result) => {
        if (err) {
            console.log(err);
        } else {
            res.send(result);
        }
    })
});


//Obtener familias y productos ulizando el join para hacer la asociacion


server.get("/menu/", (req, res) => {
    let sql = "SELECT familia.id as id_familia, familia.nombre as nombre_familia,familia.superfamilia, producto.id, producto.precio, producto.nombre, producto.descripcion from familia join producto on familia.id = producto.id_familia order by id_familia";
    db.query(sql, (err, result) => {
        if (err) {
            console.log(err);
        } else {
            res.send(result);
        }

    })
});


//obtener las superfamilias
server.get("/menu/superfamilias", (req, res) => {
    let sql = "select * from superfamilia";
    db.query(sql, (err, result) => {
        if (err) {
            console.log(err);
        } else {
            res.send(result);
        }

    })
});

//Obtener todas las familias
server.get("/menu/familias", (req, res) => {
    let sql = "select * from familia";
    db.query(sql, (err, result) => {
        if (err) {
            console.log(err);
        } else {
            res.send(result);
        }

    })
});


//obtener familia por su id
server.get("/menu/obtener/familia/:id", (req, res) => {
    const { id } = req.params;
    let sql = "select * from familia where id = ?";
    db.query(sql, [id], (err, result) => {
        if (err) {
            console.log(err);
        } else {
            res.send(result);
        }

    })
});

server.get("/menu/familia/:id", (req, res) => {
    const { id } = req.params;
    let sql = "select * from producto where id_familia = ?";
    db.query(sql, [id], (err, result) => {
        if (err) {
            console.log(err);
        } else {
            res.send(result);
        }

    })
});

//Eliminar familia y todos sus productos asociados, primero los productos luego la familia
//para no violar la restriccion de la llave foranea
server.delete("/menu/eliminar/familia", (req, res) => {
    const { id } = req.body;
    let sql = "delete from producto where id_familia = ?";
    db.query(sql, [id], (err, result) => {
        if (err) {
            console.log(err);
        } else {
            db.query("delete from familia where id = ?", [id], (err, result) => {
                if (err) {
                    console.log(err);
                }
                else {
                    res.send(result);
                }
            })
        }
    })
});


//obtener la informacion de un producto por su id
server.get("/menu/producto/:id", (req, res) => {
    const { id } = req.params;
    let sql = "select * from producto where id = ?";
    db.query(sql, [id], (err, result) => {
        if (err) {
            console.log(err);
        } else {
            res.send(result);
        }
    })
});


//editar producto
server.put("/menu/editar/producto", (req, res) => {
    const { id } = req.body;
    const { nombre } = req.body;
    const { precio } = req.body;
    const { id_familia } = req.body;
    const { descripcion } = req.body;

    let sql = "update producto set nombre = ?, precio = ?, id_familia = ?, descripcion = ? where id = ?";
    db.query(sql, [nombre, precio, id_familia, descripcion, id], (err, result) => {
        if (err) {
            console.log(err);
        } else {
            res.send(result);
        }
    })
});

//editar familia
server.put("/menu/editar/familia", (req, res) => {
    const { nombre } = req.body;
    const { id } = req.body;
    let sql = "update familia set nombre = ? where id = ? ";
    db.query(sql, [nombre, id], (err, result) => {
        if (err) {
            console.log(err);
        } else {
            res.send(result);
        }
    })
});

server.put("/menu/editar/subirfamilia", (req, res) => {
    const { id } = req.body;
    const { superfamilia } = req.body;
    let sql = "update familia set id = ? where id = ? ";
    let sql2 = "SELECT id FROM familia WHERE id = (SELECT MAX(id) FROM familia WHERE id < ? and superfamilia = ?);";
    let anterior;
    db.query(sql2, [id, superfamilia], (err, result) => {
        if (err) {
            console.log(err);
        } else {
            anterior = result[0].id;
            db.query(sql, [-1, id], (err, result2) => {
                if (err) {
                    console.log(err);
                } else {
                    db.query(sql, [id, anterior], (err, result3) => {
                        if (err) {
                            console.log(err);
                        } else {
                            db.query(sql, [anterior, -1], (err, result4) => {
                                if (err) {
                                    console.log(err);
                                } else {
                                    res.send(result4);
                                }
                            })
                        }
                    })
                }
            })
        }
    })
});

server.put("/menu/editar/bajarfamilia", (req, res) => {
    const { id } = req.body;
    const { superfamilia } = req.body;

    let sql = "update familia set id = ? where id = ? ";
    let sql2 = "SELECT id FROM familia WHERE id = (SELECT min(id) FROM familia WHERE id > ? and superfamilia = ?);";
    let siguiente;
    db.query(sql2, [id, superfamilia], (err, result) => {
        if (err) {
            console.log(err);
        } else {
            siguiente = result[0].id;
            db.query(sql, [-1, id], (err, result2) => {
                if (err) {
                    console.log(err);
                } else {
                    db.query(sql, [id, siguiente], (err, result3) => {
                        if (err) {
                            console.log(err);
                        } else {
                            db.query(sql, [siguiente, -1], (err, result4) => {
                                if (err) {
                                    console.log(err);
                                } else {
                                    res.send(result4);
                                }
                            })
                        }
                    })
                }
            })
        }
    })
});

server.put("/menu/editar/subirproducto", (req, res) => {
    const { id } = req.body;
    let sql = "update producto set id = ? where id = ? ";
    let sql2 = "SELECT id FROM producto WHERE id = (SELECT MAX(id) FROM producto WHERE id < ?);";
    let anterior;
    db.query(sql2, [id], (err, result) => {
        if (err) {
            console.log(err);
        } else {
            anterior = result[0].id;
            db.query(sql, [-1, id], (err, result2) => {
                if (err) {
                    console.log(err);
                } else {
                    db.query(sql, [id, anterior], (err, result3) => {
                        if (err) {
                            console.log(err);
                        } else {
                            db.query(sql, [anterior, -1], (err, result4) => {
                                if (err) {
                                    console.log(err);
                                } else {
                                    res.send(result4);
                                }
                            })
                        }
                    })
                }
            })
        }
    })
});

server.put("/menu/editar/bajarproducto", (req, res) => {
    const { id } = req.body;
    let sql = "update producto set id = ? where id = ? ";
    let sql2 = "SELECT id FROM producto WHERE id = (SELECT min(id) FROM producto WHERE id > ?);";
    let siguiente;
    db.query(sql2, [id], (err, result) => {
        if (err) {
            console.log(err);
        } else {
            siguiente = result[0].id;
            db.query(sql, [-1, id], (err, result2) => {
                if (err) {
                    console.log(err);
                } else {
                    db.query(sql, [id, siguiente], (err, result3) => {
                        if (err) {
                            console.log(err);
                        } else {
                            db.query(sql, [siguiente, -1], (err, result4) => {
                                if (err) {
                                    console.log(err);
                                } else {
                                    res.send(result4);
                                }
                            })
                        }
                    })
                }
            })
        }
    })
});




//Eliminar producto
server.delete("/menu/delete", (req, res) => {
    const { id } = req.body
    let sql = "DELETE FROM producto WHERE id = ?"
    db.query(sql, [id], (err, result) => { err ? console.log(err) : res.send(result) })
})

//eliminacion de productos multiple
server.delete("/menu/delete/products", (req, res) => {
    const { ids } = req.body
    let sql = "DELETE FROM producto WHERE id in (?)"
    db.query(sql, [ids], (err, result) => { err ? console.log(err) : res.send(result) })
})

//Login
server.post("/menu/login", (req, res) => {
    const username = req.body.username;
    const password = req.body.password;

    db.query("SELECT * FROM users WHERE username = ?", [username], (err, result) => {
        if (err) {
            res.send(err);
        }
        if (result.length > 0) {
            bcrypt.compare(password, result[0].password, (error, response) => {
                if (error) {
                    res.send(error);
                }
                if (response == true) {
                    res.send(response)


                } else {
                    res.send({ msg: "email ou senha incorreta" });
                }
            });
        } else {
            res.send({ msg: "Usuário não registrado!" });
        }
    });
});


server.listen(3001, () =>
    console.log("Corriendo en 3001")
);

